#pragma once

unsigned char hexToNum( char in );
char decToHex( unsigned char in );
unsigned char calculateChecksum( char * message, int len);
